#include <stdlib.h>
#include <stdio.h>
#include<string.h>

#include "file.h"

//Enumeration de chaque colonne
enum{TYPE2,IDENTIFIANT2,MARQUE,DATE2,QUANTITE2,COLUMNS2};
enum{TYPEC,IDENTIFIANTC,MARQUEC,QUANTITEC,COLUMNSC};

//fonction d'affichage sur le treeview
void affichage(GtkWidget* treeview11)
{
GtkCellRenderer *renderer;//pointeur contenant les lignes a afficher
GtkTreeViewColumn *column;//pointeur pour faire la visualisation
GtkTreeIter iter;//pointeur contient la position de la nouvelle ligne dans la liste
GtkListStore *store;//pointeur pour creer la liste
STOCK c;
char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(treeview11);
if (store==NULL)
{
//nom des colonnes
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",TYPE2, NULL);//creation du text dans la colonne
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview11), column);//ajouter la colonne pour l'afficher


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT2, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview11), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Marque", renderer, "text",MARQUE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview11), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date d'éxpiration", renderer, "text",DATE2, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview11), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Quantité", renderer, "text",QUANTITE2, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview11), column);}

//type des champs de chaque colonne qui sont des chaines de caracteres
store=gtk_list_store_new(COLUMNS2,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
//ouverture en mode lecture
f=fopen("stock.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("stock.bin","ab+");
//parcours du fichier binaire
while(fread(&c,sizeof(STOCK),1,f))
{sprintf(Date,"%d/%d/%d",c.date.jour,c.date.mois,c.date.annee);//convertir les jour/mois/année en une chaine de caracteres
gtk_list_store_append(store,&iter);
//ordonner les champs
gtk_list_store_set(store,&iter,TYPE2,c.type,IDENTIFIANT2,c.identifiant,MARQUE,c.marque,DATE2,Date,QUANTITE2,c.quantite,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(treeview11),GTK_TREE_MODEL (store));
g_object_unref(store);}}


//fonction d'ajout dans le fichier binaire
void ajout (STOCK c){
FILE*f=NULL; 
//ouverture du fichier stock.bin en mode ajout dans la derniere ligne
f=fopen("stock.bin","ab+");
//pour ecrire dans ce fichier binaire
fwrite(&c,sizeof(STOCK),1,f);
//fermeture  de fichier
fclose(f);
 
}


//fonction de suppression
void suppression(char id[30],STOCK c){
FILE*f;
//utilisation du ficher binaire auxiliaire g
FILE*g;
f=fopen("stock.bin","rb+");
//ouverture du fichier auxiliaire en mode ecriture en ecrasant son ancien contenu
g=fopen("tmp.bin","wb+");
if(g!=NULL){
//parcours du fichier stock.bin
while(fread(&c,sizeof(STOCK),1,f))
{
//comparaison de l'id avec celui écrit dans l'entry
if (strcmp(c.identifiant,id)!=0){
//si il est différent, on l'ajoute dans tmp.bin
fwrite(&c,sizeof(STOCK),1,g);
}
}
}fclose(f);
fclose(g);
//effacer l'ancien fichier
remove("stock.bin");
//changement du non du fichier tmp.bin par stock.bin
rename("tmp.bin","stock.bin");
}


//fonction de modification
void modification(char id[30],STOCK c)
{

	suppression(id,c);
	ajout(c);

}


//fonction de recherche
void recherche(GtkWidget* treeview11)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;
STOCK c;
FILE *f2;
char Date[100]; 
store=gtk_tree_view_get_model(treeview11);
if (store==NULL)
{
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Type",renderer, "text",TYPE2,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(treeview11), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",IDENTIFIANT2,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(treeview11), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Marque",renderer, "text",MARQUE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(treeview11), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Date d'éxpiration",renderer, "text",DATE2,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(treeview11), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Quantité",renderer, "text",QUANTITE2,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(treeview11), column);
}
  
store=gtk_list_store_new(COLUMNS2, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
//utilisation d'un autre fichier en mode lecture
f2=fopen("recherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("recherche.bin", "ab+");
    while(fread(&c,sizeof(STOCK),1,f2))
     {sprintf(Date,"%d/%d/%d",c.date.jour,c.date.mois,c.date.annee);
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,TYPE2,c.type,IDENTIFIANT2,c.identifiant,MARQUE,c.marque,DATE2,Date,QUANTITE2,c.quantite, -1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (treeview11), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}


//fonction permet de vérifier si l'id existe ou non
int verifid(char id[30])
{
   STOCK c;
   //variable pour tester
   int res = 1;
   FILE *f;
   f = fopen("stock.bin", "ab+");
   if (f != NULL)
   {
      while (fread(&c,sizeof(STOCK),1,f))
      {
         if (strcmp(id,c.identifiant) == 0)
         {
            res = 0;//s'ils sont égaux
         }
         else
         {
            res = 1;
         }
      }
   }
   fclose(f);
   return res;
}


//fonction permet de vérifier si on a écrit dans l'entry de l'id ou non
int veriff(char x[])
{
   int i=0;
   if (strcmp(x, "")==0)
   {
      i=0;//si l'entry est vide
   }
   else
   {
      i=1;
   }
   return i;
}


//fonction de la partie 2 (repture de stock)
void affichagestat(GtkWidget* treeview12)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
STOCK c;
char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(treeview12);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",TYPEC, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview12), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANTC, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview12), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Marque", renderer, "text",MARQUEC, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview12), column);

renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Quantité",renderer, "text",QUANTITEC,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(treeview12), column);}

store=gtk_list_store_new(COLUMNSC,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("stock.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("stock.bin","ab+");
while(fread(&c,sizeof(STOCK),1,f))
//la fct atoi fait la converssion d'une chaine vers un entier
{
if( ((strcmp(c.type,"produit1")==0)&& (atoi(c.quantite)==0))||((strcmp(c.type,"produit2")==0)&& (atoi(c.quantite)==0)) ||((strcmp(c.type,"produit3")==0)&& (atoi(c.quantite)==0)) )
{
gtk_list_store_append(store,&iter);
//mettre les valeurs dans les colonnes  
gtk_list_store_set(store,&iter,TYPEC,c.type,IDENTIFIANTC,c.identifiant,MARQUEC,c.marque,QUANTITEC,c.quantite,-1);
}}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(treeview12),GTK_TREE_MODEL (store));
g_object_unref(store);}}



