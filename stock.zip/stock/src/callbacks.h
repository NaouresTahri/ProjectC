#include <gtk/gtk.h>


void
on_button_cnx_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmenucp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrecherchrer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview11_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonsupprimer_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonactualiser_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonboard_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichboard_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
