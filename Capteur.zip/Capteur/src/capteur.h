#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
typedef struct
{
int j,m,a; 
}Date;

typedef struct
 {
char captID[20];
char captType[20];
int  captValMax;
int  captValMin;
char captBlock[20];
char captEtage[20];
Date d;
}capteur;

void ajouter(capteur C);
void modifier_capt(capteur nvCapt);
void supp_id(char id[]);
//void recherche_capteur(char Type[]);
int verif_capteur(char ID[]);
void afficher(GtkWidget *liste );
