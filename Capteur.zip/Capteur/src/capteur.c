#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "capteur.h"
#include <gtk/gtk.h>

void ajouter(capteur C)
{

FILE *f=NULL;
if(verif_capteur(C.captID)==0)
{
f=fopen("capt.txt","a") ;

if(f!=NULL)

fprintf(f,"%s %s %d %d %s %s %d %d %d\n" , C.captID ,
C.captType,C.captValMax,C.captValMin,C.captBlock,C.captEtage,C.d.j,C.d.m,C.d.a);

fclose(f);

}
else 
printf("error");

}

//////////////////////////////////////////////////////////////

void supp_id(char id[])
{
FILE *f;
    FILE *f1=NULL;
    capteur C;
    f=fopen("capt.txt","r");
    f1=fopen("tmp.txt","w");
    if(f!=NULL)
    {
        
        while(fscanf(f,"%s %s %d %d %s %s %d %d %d ", C.captID ,
C.captType,&C.captValMax,&C.captValMin,C.captBlock,C.captEtage,&C.d.j,&C.d.m,&C.d.a)!=EOF)
        {
            if(strcmp(C.captID,id)!=0)
		   
	    {

                fprintf(f1,"%s %s %d %d %s %s %d %d %d\n ", C.captID ,
C.captType,C.captValMax,C.captValMin,C.captBlock,C.captEtage,C.d.j,C.d.m,C.d.a);
            }
                

            }
        fclose(f);
        fclose(f1);

        }

    remove ("capt.txt");
    rename ("tmp.txt","capt.txt");
}


void modifier_capt(capteur nvCapt)      
{
    capteur c;
    char id[20];

FILE *f;
FILE *tmp;

f=fopen("capt.txt","r");
tmp=fopen("tmp.txt","w");
while(fscanf(f, "%s %s %d %d %s %s %d %d %d" , c.captID ,
c.captType,&c.captValMax,&c.captValMin,c.captBlock,c.captEtage,&c.d.j,&c.d.m,&c.d.a)!=EOF)
{
if (strcmp(c.captID,nvCapt.captID)==0)
{
fprintf(tmp,"%s %s %d %d %s %s %d %d %d\n" , c.captID ,
c.captType,nvCapt.captValMax,nvCapt.captValMin,nvCapt.captBlock,nvCapt.captEtage,c.d.j,c.d.m,c.d.a);
}
else
fprintf(tmp,"%s %s %d %d %s %s %d %d %d\n" , c.captID ,
c.captType,c.captValMax,c.captValMin,c.captBlock,c.captEtage,c.d.j,c.d.m,c.d.a);
}
fclose(f);
fclose(tmp);
remove("capt.txt");
rename("tmp.txt","capt.txt");

}
////////////////////////////////////////

/*void recherche_capteur(char Type)
{
FILE *f=NULL;
FILE *f1=NULL;
capteur C;

f=fopen("capt.txt","r");// ouverture du fichier capteur en  mode lecture
f1=fopen("resultat_recherche.txt","w"); // w bech a chaque fois yfase5 le9dim w yekteb el jdid
if (f!=NULL)
{
 while(fscanf(f, "%s %s  %s %s %s %s %d %d %d\n" , C.captID ,
C.captType,C.captValMax,C.captValMin,C.captBlock,C.captEtage,&C.d.j,&C.d.m,&C.d.a) )!=EOF)
{
if(strcmp(C.captType,Type)==0)
fprintf(f1,"%s %s  %s %s %s %s %d %d %d\n" , C.captID ,
C.captType,C.captValMax,C.captValMin,C.captBlock,C.captEtage,C.d.j,C.d.m,C.d.a)
}
}
close(f);
close(f1);
}*/

//////////////////////////////////////
int verif_capteur(char ID[])
{
FILE*f=NULL;
capteur C;
int existe=0;
f=fopen("capt.txt","r");
if(f!=NULL)
{
   while(fscanf(f, "%s %s  %d %d %s %s %d %d %d" , C.captID ,
C.captType,&C.captValMax,&C.captValMin,C.captBlock,C.captEtage,&C.d.j,&C.d.m,&C.d.a)!=EOF)
{
if(strcmp(C.captID,ID)==0)

existe= 1;  //id existe deja


}
fclose(f);
}
return existe;
}



enum
{
	E_ID,
        E_TYPE,
	E_VALEUR_MAX,
	E_VALEUR_MIN,
	E_BLOCK,
	E_ETAGE,
	E_JOUR,
	E_MOIS,
	E_ANNEE,
	COLUMNS
};



void afficher(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	
	char captID [20];
	char captType [20] ;
	int captValMin;
	int captValMax;
	char captBlock[20] ;
	char captEtage[20];
	int jour;
	int mois;
	int annee;
	store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captID", renderer, "text",E_ID, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captType", renderer, "text",E_TYPE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captValMax", renderer, "text",E_VALEUR_MAX, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captValMin", renderer, "text",E_VALEUR_MIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("captBlock", renderer,"text",E_BLOCK, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("captEtage", renderer,"text",E_ETAGE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",E_JOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",E_MOIS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee", renderer,"text",E_ANNEE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT,  G_TYPE_INT, G_TYPE_STRING,  G_TYPE_STRING,G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
f=fopen("capt.txt","r");
if(f==NULL)
{
return;
}
else
{
 f = fopen("capt.txt","a+");
	while(fscanf(f,"%s %s %d %d %s %s %d %d %d",captID,captType,&captValMax,&captValMin,captBlock,captEtage,&jour,&mois,&annee)!=EOF)
	{
         
	gtk_list_store_append(store, &iter);						  			 		
	gtk_list_store_set (store, &iter, E_ID, captID, E_TYPE, captType, E_VALEUR_MAX, captValMax, E_VALEUR_MIN, captValMin, E_BLOCK, captBlock,E_ETAGE, captEtage, E_JOUR, jour, E_MOIS, mois, E_ANNEE, annee,-1);		
	}
	fclose(f);
        gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}

/*void capteurs_defectueux(GtkWidget *liste){

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captID", renderer, "text",E_ID, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captType", renderer, "text",E_TYPE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captValMax", renderer, "text",E_VALEUR_MAX, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("captValMin", renderer, "text",E_VALEUR_MIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("captBlock", renderer,"text",E_BLOCK, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("captEtage", renderer,"text",E_ETAGE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour", renderer, "text",E_JOUR, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois", renderer,"text",E_MOIS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee", renderer,"text",E_ANNEE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);




}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
f=fopen("capt.txt","r");

char captID[20];
char captType[20];
int  captValMax;
int  captValMin;
char captBlock[20];
char captEtage[20];
int jour;
int mois;
int annee;
char y[30]="";
char a[30];
char b[30];
{
f=fopen("capt.txt","a+");
while(fscanf(f, "%s %s %d %d %s %s %d %d %d \n",captID,captType,&captValMax,&captValMin,captBlock,captEtage,jour,mois,annee)!=EOF)
{if (strcmp(captType,typee)==0){
if (captValMax > max || captValMin < min ){
sprintf(a,"%d",captValMax);
sprintf(b,"%d",captValMin);
strcpy(y,"");
strcat(y,jj);strcat(y,"-");strcat(y,mm);strcat(y,"-");strcat(y,aa);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,EREF,ref,ETYPE,type,EHR,hr,EETAGE,etage,EVALEUR,a,EDATE,y,-1);
}}}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}*/



