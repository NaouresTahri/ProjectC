#ifdef HAVE_CONFIG_H
# include <config.h>
#endif


#include "fonction.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>

enum
{
	EID,
	ETYPE,
	ENOM,
	ESPECIALITE,
	EDATE,
	EPRIX,
	EDESCRIPTION,
	ECOMPOSITION,
	COLUMNS,
};




int verifier(char login[],char password[])
{
int trouve=0;
FILE *f=NULL;
char ch1[20];
char ch2[20];
f=fopen("utilisateur.txt","r");  
if(f!=NULL)
{
while(fscanf(f,"%s %s",ch1,ch2)!=EOF)
{
if(strcmp(ch1,login)==0 && strcmp(ch2,password)==0)
trouve=1;
}
fclose(f);
}
return trouve;
}


menu cherchermenu(char id[])
{ 
menu T;
FILE *f;
     f=fopen("menu.txt","r");
   while( (fscanf(f,"%s %s %s %s %d %s %s %s\n",T.id,T.type,T.nom,T.specialite,&T.date,T.prix,T.description,T.composition))!=EOF)
{
if(!(strcmp(id,T.id)))
return T;
}
fclose(f);
}


    
   /* 
    iden[8],price[8],id[8],nom[10],specialite[10],description[100],date[2],type[2];
    printf("donnez l'identifiant menu a chercher  :");
    scanf("%s",iden);

strcpy(id,T[i].id);
strcpy(type,T[i].type);
strcpy(price,T[i].prix);
strcpy(date,T[i].date);
 strcpy(nom,T[i].nom);
 strcpy(specialite,T[i].specialite);
 strcpy(description,T[i].description);

    }
}
if (!(strcmp(iden,id)))
{
    printf("%s %s %s %s %s %s %s\n",iden,type,nom,specialite,date,price,description);

}
else
{
    printf("menu n existe pas\n");
}
fclose(f);
}
*/








void ajoutermenu(menu T,int specialite,int choix[])
{
FILE *F;
char texte[50]="";
F=fopen("menu.txt","a");
if(specialite== 1)
strcpy(T.specialite,"tunisienne");
if(specialite== 2)
strcpy(T.specialite,"francaise");
if(specialite== 3)
strcpy(T.specialite,"italienne");
if(choix[0]==1)
strcat(texte,"entree");
if(choix[1]==1)
strcat(texte,"plat");
if(choix[2]==1)
strcat(texte,"dessert");
if(choix[3]==1)
strcat(texte,"jus");
strcpy(T.composition,texte);
fprintf(F,"%s %s %s %s %d %s %s %s\n",T.id,T.type,T.nom,T.specialite,T.date,T.prix,T.description,T.composition);
fclose(F);
}







void modifiermenu(menu T,int spec,int ch[])
{


 

	char id[8];
	int date;
	char nom[10];	
	char specialite[20];
	char type[2];
	char prix[8];
	char description[100];
	char composition[50];

FILE *f ;

FILE *fi ;

 

 

f=fopen("menu.txt","r");

fi=fopen("menuu.txt","w+");

 

 char texte[50]="";
if(spec== 1)
strcpy(T.specialite,"tunisienne");
if(spec== 2)
strcpy(T.specialite,"francaise");
if(spec== 3)
strcpy(T.specialite,"italienne");
if(ch[0]==1)
strcat(texte,"entree");
if(ch[1]==1)
strcat(texte,"plat");
if(ch[2]==1)
strcat(texte,"dessert");
if(ch[3]==1)
strcat(texte,"jus");
strcpy(T.composition,texte);

 

if(f != NULL)

{

             if (fi != NULL )

             {

             while((fscanf(f,"%s %s %s %s %d %s %s %s\n",id,type,nom,specialite,&date,prix,description,composition))!=EOF )

                          

             {

                           if (strcmp(T.id,id)!=0)

                                        {

                                        fprintf(fi,"%s %s %s %s %d %s %s %s\n",id,type,nom,specialite,date,prix,description,composition);

                                   }

                           else

                                      

                           {

                           fprintf(fi,"%s %s %s %s %d %s %s %s\n",T.id,T.type,T.nom,T.specialite,T.date,T.prix,T.description,T.composition);

            

                           }

}}}

 

 

             fclose(f);

             fclose(fi);        

            

                           remove("menu.txt");

                           rename("menuu.txt","menu.txt");

}





void affichermenu(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

	char id[8];
	char type[2];
	char nom[10];	
	char specialite[20];
	int date;
	char prix[8];
	char description[100];
	char composition[50];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new(); 
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("specialite",renderer,"text",ESPECIALITE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("description",renderer,"text",EDESCRIPTION,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("composition",renderer,"text",ECOMPOSITION,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
}
store=gtk_list_store_new (COLUMNS , G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_INT ,G_TYPE_STRING ,G_TYPE_STRING,G_TYPE_STRING  );

f=fopen("menu.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("menu.txt","a+");
while((fscanf(f,"%s %s %s %s %d %s %s %s\n",id,type,nom,specialite,&date,prix,description,composition))!=EOF)
{
	gtk_list_store_append(store, &iter);
	gtk_list_store_set(store,&iter,EID,id,ETYPE,type,ENOM,nom,ESPECIALITE,specialite,EDATE,date,EPRIX,prix,EDESCRIPTION,description,ECOMPOSITION,composition,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}

}

char* meilleurmenu(int semaine)
{
    char *me=NULL;
    char ml[10];
int jourmeill;
FILE *f;
float min=100;
int typefin;
meilleur m;
menu T;
int typ;
int j=semaine+7;
f=fopen("dechets.txt","a+");

while((fscanf(f,"%d %d %f\n",&m.jour,&m.type,&m.dech))!=EOF)
{
    if((m.jour>semaine)&&(m.jour<j))
{if(m.dech<min)
{
    min=m.dech;
jourmeill=m.jour;
typ=m.type;
}

}
}



fclose(f);
f=fopen("menu.txt","r");
printf("fichier ouvert\n");
 while((fscanf(f,"%s %s %s %s %d %s %s %s\n",T.id,T.type,T.nom,T.specialite,&T.date,T.prix,T.description,T.composition))!=EOF){
if((jourmeill==T.date) && (atoi(T.type)==typ))
{

strcpy(ml,T.nom);
}
}
fclose(f);
me=malloc((strlen(ml)+1)*sizeof(char));
strcpy(me,ml);
return me;
}





void supprimermenu(menu T)
{
	char id[8];
	char type[2];
	char nom[10];	
	char specialite[20];
	int date;
	char prix[8];
	char description[100];
	char composition[50];
    FILE *f,*g;

     f=fopen("menu.txt","r");
	g=fopen("dump.txt","w");


if(f==NULL || g==NULL)
{
return;
}
else{
  while(fscanf(f,"%s %s %s %s %d %s %s %s\n",id,type,nom,specialite,&date,prix,description,composition)!=EOF)
{
    if (strcmp(T.id,id)!=0)
fprintf(g,"%s %s %s %s %d %s %s %s\n",id,type,nom,specialite,date,prix,description,composition);
}

fclose(f);
fclose(g);
remove("menu.txt");
rename("dump.txt","menu.txt");
}
}



void vider(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

	char id[8];
	char type[2];
	char nom[10];	
	char specialite[20];
	int date;
	char prix[8];
	char description[100];
char composition[50];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new(); 
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("specialite",renderer,"text",ESPECIALITE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",EDATE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",EPRIX,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("description",renderer,"text",EDESCRIPTION,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("composition",renderer,"text",ECOMPOSITION,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
}

store=gtk_list_store_new (COLUMNS , G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_INT ,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING);

gtk_list_store_append(store,&iter);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste) ,GTK_TREE_MODEL(store));








}



