#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
int choix[]={0,0,0,0};
int ch[]={0,0,0,0};
void
on_button2_auth_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *username, *password, *windowEspaceAdmin;
char user[20];
char passw[20];
int trouve;
username = lookup_widget (button, "entry3_log");
password = lookup_widget (button, "entry4_Pw");
strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(passw, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=verifier(user,passw);

if(trouve==1)
{
windowEspaceAdmin=create_Admin();
gtk_widget_show (windowEspaceAdmin);
}
else
printf("\n vous n etes pas inscrit");
}

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* id;

menu T;

GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if( gtk_tree_model_get_iter(model, &iter, path))
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);

strcpy(T.id,id);

supprimermenu(T);
affichermenu(treeview);
}


void
on_retourner_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajouter_une_menu, *afficher;
afficher=lookup_widget(objet,"afficher");
gtk_widget_destroy(afficher);
ajouter_une_menu=create_ajouter_une_menu();
gtk_widget_show(ajouter_une_menu);
}

int specialite=1;
void
on_buttonvalider_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{

menu T;
char texte[50];
GtkWidget *input1,*combobox1,*input3,*jour,*input6,*input7;
GtkWidget *ajouter_une_menu;
ajouter_une_menu=lookup_widget(objet,"ajouter_une_menu");
input1=lookup_widget(objet,"id");
combobox1=lookup_widget(objet,"combobox1");
input3=lookup_widget(objet,"nom");
jour=lookup_widget(objet,"jour");
input6=lookup_widget(objet,"prix");
input7=lookup_widget(objet,"description");




T.date=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
strcpy(T.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(T.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(T.nom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(T.prix,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(T.description,gtk_entry_get_text(GTK_ENTRY(input7)));
ajoutermenu(T,specialite,choix);


}


void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajouter_une_menu;
GtkWidget *afficher;
GtkWidget *treeview1;

ajouter_une_menu=lookup_widget(objet,"ajouter_une_menu");


gtk_widget_destroy(ajouter_une_menu);
afficher=lookup_widget(objet,"ajouter_une_menu");
afficher=create_afficher();

gtk_widget_show(afficher);

treeview1=lookup_widget(afficher,"treeview1");

affichermenu(treeview1);

}
void on_Actualiser_clicked(GtkWidget *objet,gpointer user_data)
{
GtkWidget *afficher,*w;
GtkWidget *treeview1;
w=lookup_widget(objet,"afficher");
afficher=create_afficher();
gtk_widget_show(afficher);
gtk_widget_hide(w);
treeview1=lookup_widget(afficher,"treeview1");
vider(treeview1);
affichermenu(treeview1);
}

void
on_se_connecter_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}




int spec=1;
void
on_tunisienne_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
specialite=1;
spec=1;
}


void
on_francaise_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
specialite=2;
spec=2;
}


void
on_italienne_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
specialite=3;
spec=3;
}



void
on_jus_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
choix[3]=1;
ch[3]=1;
}
}


void
on_dessert_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
choix[2]=1;
ch[2]=1;
}
}


void
on_plat_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
choix[1]=1;
ch[1]=1;
}
}


void
on_entree_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
choix[0]=1;
ch[0]=1;
}
}


void
on_ajouter_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajouter_une_menu, *admin;
admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(admin);
ajouter_une_menu=create_ajouter_une_menu();
gtk_widget_show(ajouter_une_menu);
}




void
on_afficher_liste_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *afficher, *admin;
admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(admin);
afficher=create_afficher();
gtk_widget_show(afficher);
}


void
on_retour_menu_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajouter_une_menu, *admin;
ajouter_une_menu=lookup_widget(objet,"ajouter_une_menu");
gtk_widget_destroy(ajouter_une_menu);
admin=create_Admin();
gtk_widget_show(admin);
}


void
on_retour_clicked                      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *afficher, *admin;
afficher=lookup_widget(objet,"afficher");
gtk_widget_destroy(afficher);
admin=create_Admin();
gtk_widget_show(admin);
}


void
on_verifier_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
char id[8];
menu T;
GtkWidget *input;
input=lookup_widget(objet,"entryid");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
T=cherchermenu(id);
GtkWidget *tunisienne, *francaise , *italienne;
GtkWidget *output;
output=lookup_widget(objet,"verif");
tunisienne=lookup_widget(objet,"tunisienne");
francaise=lookup_widget(objet,"francaise");
italienne=lookup_widget(objet,"italienne");
if(!(strcmp(T.specialite,"tunisienne")))
{
gtk_toggle_button_set_active(GTK_RADIO_BUTTON(tunisienne),TRUE);
gtk_label_set_text(GTK_LABEL(output),"la specialite est tunisienne");
}
else if(!(strcmp(T.specialite,"francaise")))
{
gtk_toggle_button_set_active(GTK_RADIO_BUTTON(francaise),TRUE);
gtk_label_set_text(GTK_LABEL(output),"la specialite est francaise");
}
else if(!(strcmp(T.specialite,"italienne")))
{
gtk_toggle_button_set_active(GTK_RADIO_BUTTON(italienne),TRUE);
gtk_label_set_text(GTK_LABEL(output),"la specialite est italienne");
}
else 
gtk_label_set_text(GTK_LABEL(output),"verifier l'id");
}


void
on_modifier_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
menu T;
char texte[50];
GtkWidget *input1,*combobox1,*input3,*jour,*input6,*input7;
GtkWidget *ajouter_une_menu;
ajouter_une_menu=lookup_widget(objet,"ajouter_une_menu");
input1=lookup_widget(objet,"id");
combobox1=lookup_widget(objet,"combobox1");
input3=lookup_widget(objet,"nom");
jour=lookup_widget(objet,"jour");
input6=lookup_widget(objet,"prix");
input7=lookup_widget(objet,"description");




T.date=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
strcpy(T.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(T.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(T.nom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(T.prix,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(T.description,gtk_entry_get_text(GTK_ENTRY(input7)));
modifiermenu(T,spec,ch);
}


void
on_valide_clicked                      (GtkButton       *objet,
                                        gpointer         user_data)
{
   char *m;
int semaine;
char s[2];
GtkWidget *combobox2;
combobox2=lookup_widget(objet,"combobox2");
strcpy(s,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
semaine=atoi(s);
m=meilleurmenu(semaine);
GtkWidget *output;
output=lookup_widget(objet,"resultat");
gchar* sUtf8;
sUtf8=g_strdup_printf("%s",m);
gtk_label_set_text(GTK_LABEL(output),sUtf8);
g_free(sUtf8);
free(m);
}


void
on_modif_clicked                       (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajouter_une_menu, *admin;
admin=lookup_widget(objet,"Admin");
gtk_widget_destroy(admin);
ajouter_une_menu=create_ajouter_une_menu();
gtk_widget_show(ajouter_une_menu);
}

