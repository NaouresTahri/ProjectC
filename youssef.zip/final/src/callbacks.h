#include <gtk/gtk.h>



void
on_button2_auth_clicked                (GtkWidget       *button,
                                        gpointer         user_data);


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retourner_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonvalider_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_se_connecter_clicked                (GtkButton       *button,
                                        gpointer         user_data);
void on_Actualiser_clicked(GtkWidget *objet,gpointer user_data);



void
on_tunisienne_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_francaise_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_italienne_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_jus_toggled                         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_dessert_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_plat_toggled                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_entree_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);


void
on_afficher_liste_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_menu_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_verifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_valide_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_modif_clicked                       (GtkButton       *button,
                                        gpointer         user_data);
