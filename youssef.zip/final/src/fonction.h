#include <gtk/gtk.h>

typedef struct 
{ 
	char id[8];
	char type[2];
	char nom[10];	
	char specialite[20];
	int date;
	char prix[8];
	char description[100];
	char composition[50];
}menu;
typedef struct{
int jour;
int type;
float dech;
}meilleur;
int verifier(char login[],char password[]);
void ajoutermenu(menu T,int specialite,int choix[]);
void modifiermenu(menu T,int spec,int ch[]);
void supprimermenu(menu T);
void affichermenu(GtkWidget *liste);
//int recherchermenu(menu T[],menu r);
menu cherchermenu(char id[]);
char* meilleurmenu(int semaine);


